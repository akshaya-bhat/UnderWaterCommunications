#!/bin/sh 
qemu-aarch64 -L /usr/aarch64-linux-gnu "$@"