#pragma once

#define CONSOLE_RESET "\033[0m"
#define CONSOLE_RED   "\033[31m"
#define CONSOLE_GREEN "\033[32m"