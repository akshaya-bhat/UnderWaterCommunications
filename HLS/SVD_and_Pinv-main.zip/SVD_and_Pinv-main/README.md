# SVD_and_Pinv
Singular value decomposition and pseudo inverse functions

This code features singular value decomposition and pseudo inverse functions. 
There are also QR decompostion and eigen decomposition sub modules. Note that the simple eigen decomposition code works for symmetric matrices only.
